package bk.view.cashout;

import androidx.appcompat.app.AppCompatActivity;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    public Double money;
    TextView mCashTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("Coin Counter");
        money = 0.00;
        mCashTextView = findViewById(R.id.txtCash);
        mCashTextView.setText(formatString(money));


        findViewById(R.id.imgPenny).setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                addPenny();
            }
        });


        findViewById(R.id.imgNickel).setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                addNickel();
            }
        });

        findViewById(R.id.imgDime).setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                addDime();
            }
        });

        findViewById(R.id.imgQuarter).setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                addQuarter();
            }
        });

        findViewById(R.id.btn_cashOut).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cashOut();
            }
        });
    }

    private void addPenny() {
        money = money + 0.01;
        mCashTextView.setText(formatString(money));
    }

    private void addNickel() {
        money = money + 0.05;
        mCashTextView.setText(formatString(money));
    }

    private void addDime() {
        money = money + 0.10;
        mCashTextView.setText(formatString(money));
    }

    private void addQuarter() {
        money = money + 0.25;
        mCashTextView.setText(formatString(money));
    }

    private void cashOut() {

        final MediaPlayer mp = MediaPlayer.create(this, R.raw.cash);
        mp.start();
        money = 0.00;
        mCashTextView.setText(formatString(money));
    }

    private String formatString(Double money) {
        return String.format("$%.2f", money);
    }
}
